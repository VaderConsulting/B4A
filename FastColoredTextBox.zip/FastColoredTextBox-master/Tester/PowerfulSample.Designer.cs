﻿using FastColoredTextBoxNS;
namespace Tester
{
    partial class PowerfulSample
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PowerfulSample));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.setSelectedAsReadonlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setSelectedAsWritableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.collapseSelectedBlockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.collapseAllregionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exapndAllregionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.increaseIndentSiftTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.decreaseIndentTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.goBackwardCtrlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goForwardCtrlShiftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.autoIndentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.goLeftBracketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goRightBracketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.miPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.startStopMacroRecordingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.executeMacroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miLanguage = new System.Windows.Forms.ToolStripMenuItem();
            this.miCSharp = new System.Windows.Forms.ToolStripMenuItem();
            this.cSharpbuiltinHighlighterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miVB = new System.Windows.Forms.ToolStripMenuItem();
            this.hTMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pHPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miExport = new System.Windows.Forms.ToolStripMenuItem();
            this.hTMLToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.miChangeColors = new System.Windows.Forms.ToolStripMenuItem();
            this.fctb = new FastColoredTextBoxNS.FastColoredTextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fctb)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.miLanguage,
            this.miExport,
            this.miChangeColors});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(387, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findToolStripMenuItem,
            this.replaceToolStripMenuItem,
            this.toolStripMenuItem1,
            this.setSelectedAsReadonlyToolStripMenuItem,
            this.setSelectedAsWritableToolStripMenuItem,
            this.toolStripMenuItem8,
            this.collapseSelectedBlockToolStripMenuItem,
            this.toolStripMenuItem3,
            this.collapseAllregionToolStripMenuItem,
            this.exapndAllregionToolStripMenuItem,
            this.toolStripMenuItem2,
            this.increaseIndentSiftTabToolStripMenuItem,
            this.decreaseIndentTabToolStripMenuItem,
            this.toolStripMenuItem4,
            this.goBackwardCtrlToolStripMenuItem,
            this.goForwardCtrlShiftToolStripMenuItem,
            this.toolStripMenuItem5,
            this.autoIndentToolStripMenuItem,
            this.toolStripMenuItem6,
            this.goLeftBracketToolStripMenuItem,
            this.goRightBracketToolStripMenuItem,
            this.toolStripMenuItem7,
            this.miPrint,
            this.toolStripMenuItem9,
            this.startStopMacroRecordingToolStripMenuItem,
            this.executeMacroToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // findToolStripMenuItem
            // 
            this.findToolStripMenuItem.Name = "findToolStripMenuItem";
            this.findToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.findToolStripMenuItem.Text = "&Find [Ctrl+F]";
            this.findToolStripMenuItem.Click += new System.EventHandler(this.findToolStripMenuItem_Click);
            // 
            // replaceToolStripMenuItem
            // 
            this.replaceToolStripMenuItem.Name = "replaceToolStripMenuItem";
            this.replaceToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.replaceToolStripMenuItem.Text = "&Replace [Ctrl+H]";
            this.replaceToolStripMenuItem.Click += new System.EventHandler(this.replaceToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(264, 6);
            // 
            // setSelectedAsReadonlyToolStripMenuItem
            // 
            this.setSelectedAsReadonlyToolStripMenuItem.Name = "setSelectedAsReadonlyToolStripMenuItem";
            this.setSelectedAsReadonlyToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.setSelectedAsReadonlyToolStripMenuItem.Text = "Set selected as readonly";
            this.setSelectedAsReadonlyToolStripMenuItem.Click += new System.EventHandler(this.setSelectedAsReadonlyToolStripMenuItem_Click);
            // 
            // setSelectedAsWritableToolStripMenuItem
            // 
            this.setSelectedAsWritableToolStripMenuItem.Name = "setSelectedAsWritableToolStripMenuItem";
            this.setSelectedAsWritableToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.setSelectedAsWritableToolStripMenuItem.Text = "Set selected as writable";
            this.setSelectedAsWritableToolStripMenuItem.Click += new System.EventHandler(this.setSelectedAsWritableToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(264, 6);
            // 
            // collapseSelectedBlockToolStripMenuItem
            // 
            this.collapseSelectedBlockToolStripMenuItem.Name = "collapseSelectedBlockToolStripMenuItem";
            this.collapseSelectedBlockToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.collapseSelectedBlockToolStripMenuItem.Text = "Collapse selected block";
            this.collapseSelectedBlockToolStripMenuItem.Click += new System.EventHandler(this.collapseSelectedBlockToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(264, 6);
            // 
            // collapseAllregionToolStripMenuItem
            // 
            this.collapseAllregionToolStripMenuItem.Name = "collapseAllregionToolStripMenuItem";
            this.collapseAllregionToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.collapseAllregionToolStripMenuItem.Text = "Collapse all #region";
            this.collapseAllregionToolStripMenuItem.Click += new System.EventHandler(this.collapseAllregionToolStripMenuItem_Click);
            // 
            // exapndAllregionToolStripMenuItem
            // 
            this.exapndAllregionToolStripMenuItem.Name = "exapndAllregionToolStripMenuItem";
            this.exapndAllregionToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.exapndAllregionToolStripMenuItem.Text = "Exapnd all #region";
            this.exapndAllregionToolStripMenuItem.Click += new System.EventHandler(this.exapndAllregionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(264, 6);
            // 
            // increaseIndentSiftTabToolStripMenuItem
            // 
            this.increaseIndentSiftTabToolStripMenuItem.Name = "increaseIndentSiftTabToolStripMenuItem";
            this.increaseIndentSiftTabToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.increaseIndentSiftTabToolStripMenuItem.Text = "Increase Indent [Tab]";
            this.increaseIndentSiftTabToolStripMenuItem.Click += new System.EventHandler(this.increaseIndentSiftTabToolStripMenuItem_Click);
            // 
            // decreaseIndentTabToolStripMenuItem
            // 
            this.decreaseIndentTabToolStripMenuItem.Name = "decreaseIndentTabToolStripMenuItem";
            this.decreaseIndentTabToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.decreaseIndentTabToolStripMenuItem.Text = "Decrease Indent [Shift + Tab]";
            this.decreaseIndentTabToolStripMenuItem.Click += new System.EventHandler(this.decreaseIndentTabToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(264, 6);
            // 
            // goBackwardCtrlToolStripMenuItem
            // 
            this.goBackwardCtrlToolStripMenuItem.Name = "goBackwardCtrlToolStripMenuItem";
            this.goBackwardCtrlToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.goBackwardCtrlToolStripMenuItem.Text = "Go Backward [Ctrl+ -]";
            this.goBackwardCtrlToolStripMenuItem.Click += new System.EventHandler(this.goBackwardCtrlToolStripMenuItem_Click);
            // 
            // goForwardCtrlShiftToolStripMenuItem
            // 
            this.goForwardCtrlShiftToolStripMenuItem.Name = "goForwardCtrlShiftToolStripMenuItem";
            this.goForwardCtrlShiftToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.goForwardCtrlShiftToolStripMenuItem.Text = "Go Forward [Ctrl+Shift+ -]";
            this.goForwardCtrlShiftToolStripMenuItem.Click += new System.EventHandler(this.goForwardCtrlShiftToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(264, 6);
            // 
            // autoIndentToolStripMenuItem
            // 
            this.autoIndentToolStripMenuItem.Name = "autoIndentToolStripMenuItem";
            this.autoIndentToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.autoIndentToolStripMenuItem.Text = "Auto Indent selected text";
            this.autoIndentToolStripMenuItem.Click += new System.EventHandler(this.autoIndentToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(264, 6);
            // 
            // goLeftBracketToolStripMenuItem
            // 
            this.goLeftBracketToolStripMenuItem.Name = "goLeftBracketToolStripMenuItem";
            this.goLeftBracketToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.goLeftBracketToolStripMenuItem.Text = "Go Left Bracket";
            this.goLeftBracketToolStripMenuItem.Click += new System.EventHandler(this.goLeftBracketToolStripMenuItem_Click);
            // 
            // goRightBracketToolStripMenuItem
            // 
            this.goRightBracketToolStripMenuItem.Name = "goRightBracketToolStripMenuItem";
            this.goRightBracketToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.goRightBracketToolStripMenuItem.Text = "Go Right Bracket";
            this.goRightBracketToolStripMenuItem.Click += new System.EventHandler(this.goRightBracketToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(264, 6);
            // 
            // miPrint
            // 
            this.miPrint.Name = "miPrint";
            this.miPrint.Size = new System.Drawing.Size(267, 22);
            this.miPrint.Text = "Print...";
            this.miPrint.Click += new System.EventHandler(this.miPrint_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(264, 6);
            // 
            // startStopMacroRecordingToolStripMenuItem
            // 
            this.startStopMacroRecordingToolStripMenuItem.Name = "startStopMacroRecordingToolStripMenuItem";
            this.startStopMacroRecordingToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.startStopMacroRecordingToolStripMenuItem.Text = "Start/Stop macro recording [Ctrl+M]";
            this.startStopMacroRecordingToolStripMenuItem.Click += new System.EventHandler(this.startStopMacroRecordingToolStripMenuItem_Click);
            // 
            // executeMacroToolStripMenuItem
            // 
            this.executeMacroToolStripMenuItem.Name = "executeMacroToolStripMenuItem";
            this.executeMacroToolStripMenuItem.Size = new System.Drawing.Size(267, 22);
            this.executeMacroToolStripMenuItem.Text = "Execute macro [Ctrl+E]";
            this.executeMacroToolStripMenuItem.Click += new System.EventHandler(this.executeMacroToolStripMenuItem_Click);
            // 
            // miLanguage
            // 
            this.miLanguage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miCSharp,
            this.cSharpbuiltinHighlighterToolStripMenuItem,
            this.miVB,
            this.hTMLToolStripMenuItem,
            this.sQLToolStripMenuItem,
            this.pHPToolStripMenuItem,
            this.jSToolStripMenuItem});
            this.miLanguage.Name = "miLanguage";
            this.miLanguage.Size = new System.Drawing.Size(71, 20);
            this.miLanguage.Text = "Language";
            this.miLanguage.DropDownOpening += new System.EventHandler(this.miLanguage_DropDownOpening);
            // 
            // miCSharp
            // 
            this.miCSharp.Name = "miCSharp";
            this.miCSharp.Size = new System.Drawing.Size(224, 22);
            this.miCSharp.Text = "CSharp (custom highlighter)";
            this.miCSharp.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // cSharpbuiltinHighlighterToolStripMenuItem
            // 
            this.cSharpbuiltinHighlighterToolStripMenuItem.Name = "cSharpbuiltinHighlighterToolStripMenuItem";
            this.cSharpbuiltinHighlighterToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.cSharpbuiltinHighlighterToolStripMenuItem.Text = "CSharp (built-in highlighter)";
            this.cSharpbuiltinHighlighterToolStripMenuItem.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // miVB
            // 
            this.miVB.Name = "miVB";
            this.miVB.Size = new System.Drawing.Size(224, 22);
            this.miVB.Text = "VB";
            this.miVB.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // hTMLToolStripMenuItem
            // 
            this.hTMLToolStripMenuItem.Name = "hTMLToolStripMenuItem";
            this.hTMLToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.hTMLToolStripMenuItem.Text = "HTML";
            this.hTMLToolStripMenuItem.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // sQLToolStripMenuItem
            // 
            this.sQLToolStripMenuItem.Name = "sQLToolStripMenuItem";
            this.sQLToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.sQLToolStripMenuItem.Text = "SQL";
            this.sQLToolStripMenuItem.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // pHPToolStripMenuItem
            // 
            this.pHPToolStripMenuItem.Name = "pHPToolStripMenuItem";
            this.pHPToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.pHPToolStripMenuItem.Text = "PHP";
            this.pHPToolStripMenuItem.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // jSToolStripMenuItem
            // 
            this.jSToolStripMenuItem.Name = "jSToolStripMenuItem";
            this.jSToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.jSToolStripMenuItem.Text = "JS";
            this.jSToolStripMenuItem.Click += new System.EventHandler(this.miCSharp_Click);
            // 
            // miExport
            // 
            this.miExport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hTMLToolStripMenuItem1});
            this.miExport.Name = "miExport";
            this.miExport.Size = new System.Drawing.Size(52, 20);
            this.miExport.Text = "Export";
            // 
            // hTMLToolStripMenuItem1
            // 
            this.hTMLToolStripMenuItem1.Name = "hTMLToolStripMenuItem1";
            this.hTMLToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.hTMLToolStripMenuItem1.Text = "HTML";
            this.hTMLToolStripMenuItem1.Click += new System.EventHandler(this.hTMLToolStripMenuItem1_Click);
            // 
            // miChangeColors
            // 
            this.miChangeColors.Enabled = false;
            this.miChangeColors.Name = "miChangeColors";
            this.miChangeColors.Size = new System.Drawing.Size(134, 20);
            this.miChangeColors.Text = "Change color scheme";
            this.miChangeColors.Click += new System.EventHandler(this.miChangeColors_Click);
            // 
            // fctb
            // 
            this.fctb.AutoIndentExistingLines = false;
            this.fctb.AutoScrollMinSize = new System.Drawing.Size(284, 285);
            this.fctb.BackBrush = null;
            this.fctb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fctb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fctb.DelayedEventsInterval = 200;
            this.fctb.DelayedTextChangedInterval = 500;
            this.fctb.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.fctb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fctb.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fctb.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.fctb.IsReplaceMode = false;
            this.fctb.LeftBracket = '(';
            this.fctb.Location = new System.Drawing.Point(0, 24);
            this.fctb.Name = "fctb";
            this.fctb.Paddings = new System.Windows.Forms.Padding(0);
            this.fctb.ReservedCountOfLineNumberChars = 2;
            this.fctb.RightBracket = ')';
            this.fctb.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.fctb.Size = new System.Drawing.Size(387, 332);
            this.fctb.TabIndex = 3;
            this.fctb.Text = resources.GetString("fctb.Text");
            this.fctb.TextChanged += new System.EventHandler<FastColoredTextBoxNS.TextChangedEventArgs>(this.fctb_TextChanged);
            this.fctb.SelectionChangedDelayed += new System.EventHandler(this.fctb_SelectionChangedDelayed);
            this.fctb.AutoIndentNeeded += new System.EventHandler<FastColoredTextBoxNS.AutoIndentEventArgs>(this.fctb_AutoIndentNeeded);
            // 
            // PowerfulSample
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 356);
            this.Controls.Add(this.fctb);
            this.Controls.Add(this.menuStrip1);
            this.ImeMode = System.Windows.Forms.ImeMode.Hiragana;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PowerfulSample";
            this.Text = "FastColoredTextBox sample";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fctb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private FastColoredTextBox fctb;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miLanguage;
        private System.Windows.Forms.ToolStripMenuItem miCSharp;
        private System.Windows.Forms.ToolStripMenuItem miVB;
        private System.Windows.Forms.ToolStripMenuItem collapseAllregionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exapndAllregionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem increaseIndentSiftTabToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem decreaseIndentTabToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hTMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem miExport;
        private System.Windows.Forms.ToolStripMenuItem hTMLToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem collapseSelectedBlockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHPToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem goBackwardCtrlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goForwardCtrlShiftToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem autoIndentToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem goLeftBracketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goRightBracketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem miPrint;
        private System.Windows.Forms.ToolStripMenuItem miChangeColors;
        private System.Windows.Forms.ToolStripMenuItem cSharpbuiltinHighlighterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setSelectedAsReadonlyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setSelectedAsWritableToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem startStopMacroRecordingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem executeMacroToolStripMenuItem;
    }
}


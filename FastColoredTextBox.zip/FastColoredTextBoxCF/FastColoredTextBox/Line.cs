﻿using System.Collections.Generic;
using System;
using System.Text;

namespace FastColoredTextBoxNS
{
    /// <summary>
    /// Line of text
    /// </summary>
    public class Line : List<Char>
    {
        List<int> cutOffPositions;
        public string FoldingStartMarker { get; set; }
        public string FoldingEndMarker { get; set; }
        /// <summary>
        /// Text of line was changed
        /// </summary>
        public bool IsChanged { get; set; }
        /// <summary>
        /// Time of last visit of caret in this line
        /// </summary>
        /// <remarks>This property can be used for forward/backward navigating</remarks>
        public DateTime LastVisit { get; set; }
        //Y coordinate of line on screen
        internal int startY = -1;
        /// <summary>
        /// Visible state
        /// </summary>
        public VisibleState VisibleState { get; set; }
        /// <summary>
        /// AutoIndent level for this line
        /// </summary>
        public int IndentLevel { get; set; }
        /// <summary>
        /// User tag
        /// </summary>
        public object Tag { get; set; }

        /// <summary>
        /// Clears style of chars, delete folding markers
        /// </summary>
        public void ClearStyle(StyleIndex styleIndex)
        {
            VisibleState = VisibleState.Visible;
            FoldingStartMarker = null;
            FoldingEndMarker = null;
            for (int i = 0; i < Count; i++)
            {
                Char c = this[i];
                c.style &= ~styleIndex;
                this[i] = c;
            }
        }

        /// <summary>
        /// Text of the line
        /// </summary>
        public string Text
        {
            get{
                StringBuilder sb = new StringBuilder(Count);
                foreach(Char c in this)
                    sb.Append(c.c);
                return sb.ToString();
            }
        }

        /// <summary>
        /// Clears folding markers
        /// </summary>
        public void ClearFoldingMarkers()
        {
            FoldingStartMarker = null;
            FoldingEndMarker = null;
        }

        /// <summary>
        /// Positions for wordwrap cutoffs
        /// </summary>
        public List<int> CutOffPositions
        {
            get
            {
                if (cutOffPositions == null)
                    cutOffPositions = new List<int>();
                return cutOffPositions;
            }
        }

        /// <summary>
        /// Count of wordwrap string count for this line
        /// </summary>
        public int WordWrapStringsCount
        {
            get
            {
                if (VisibleState == VisibleState.Hidden) 
                    return 0;
                if (VisibleState == VisibleState.StartOfHiddenBlock)
                    return 1;
                if (cutOffPositions == null)
                    return 1;
                return cutOffPositions.Count + 1;
            }
        }

        internal int GetWordWrapStringStartPosition(int iWordWrapLine)
        {
            return iWordWrapLine == 0 ? 0 : CutOffPositions[iWordWrapLine - 1];
        }

        internal int GetWordWrapStringFinishPosition(int iWordWrapLine)
        {
            if (WordWrapStringsCount <= 0)
                return 0;
            return iWordWrapLine == WordWrapStringsCount - 1 ? Count - 1 : CutOffPositions[iWordWrapLine] - 1;
        }

        /// <summary>
        /// Gets index of wordwrap string for given char position
        /// </summary>
        public int GetWordWrapStringIndex(int iChar)
        {
            if (cutOffPositions == null || cutOffPositions.Count == 0) return 0;
            for (int i = 0; i < cutOffPositions.Count; i++)
                if (cutOffPositions[i] >/*>=*/ iChar)
                    return i;
            return cutOffPositions.Count;
        }

        /// <summary>
        /// Calculates wordwrap cutoffs
        /// </summary>
        internal void CalcCutOffs(int maxCharsPerLine, bool charWrap)
        {
            int segmentLength = 0;
            int cutOff = 0;
            CutOffPositions.Clear();

            for (int i = 0; i < Count; i++)
            {
                char c = this[i].c;
                if (charWrap)
                {
                    //char wrapping
                    cutOff = Math.Min(i + 1, Count - 1);
                }
                else
                {
                    //word wrapping
                    if (!char.IsLetterOrDigit(c) && c != '_')
                        cutOff = Math.Min(i + 1, Count - 1);
                }

                segmentLength++;

                if (segmentLength == maxCharsPerLine)
                {
                    if (cutOff == 0 || (cutOffPositions.Count > 0 && cutOff == cutOffPositions[cutOffPositions.Count - 1]))
                        cutOff = i + 1;
                    CutOffPositions.Add(cutOff);
                    segmentLength = 1 + i - cutOff;
                }
            }
        }

        /// <summary>
        /// Count of start spaces
        /// </summary>
        public int StartSpacesCount
        {
            get
            {
                int spacesCount = 0;
                for (int i = 0; i < Count; i++)
                    if (this[i].c == ' ')
                        spacesCount++;
                    else
                        break;
                return spacesCount;
            }
        }
    }

    public enum VisibleState
    {
        Visible, StartOfHiddenBlock, Hidden
    }

    public enum IndentMarker
    {
        None,
        Increased,
        Decreased
    }
}
